from colorama import Fore

def main():
    print(Fore.RED + 'Hello, World!')

if __name__ == '__main__':
    main()
